# LAB WSI
Implementacje algorytmów znajdują się w folderze `src/algorithms`.
Raporty znajdują się w folderze `notebooks/lab{nr_lab}/lab{nr_lab}.ipynb`

`pip install -r requirements.txt`
