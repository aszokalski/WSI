# Lab 4 - SVM

Prosze napisac maszyne wektorow nosnych, ktora rozwiaze problem klasyfikacji cyfr ze zbioru MNIST. 

Prosze o:
- wykresy przebiegu treningu, 
- zobrazowac confusion matrix,
- opis parametrow takich jak:
  - skutecznosc, 
  - f1-score,
  - precyzje, 
  - rozrzut
