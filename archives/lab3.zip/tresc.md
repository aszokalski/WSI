# Laboratorium 3

Napisac program, ktory buduje drzewo gry dla gry kółko i krzyżyk na planszy 3x3, a
następnie gra sam ze sobą w sposób losowy (losuje wynik) i odrzuca ścieżki, które prowadzą do przegranej.

Aby zdobyc maksymalna ilosc punktow trzeba:

- przetestowac na wiekszej ilosci prob
- zaprezentowac przykladowa gre i jak dzialal algorytm - czy dobrze wybieral ruchy
- zaprezentowac wykresy do przeprowadzonych prob

Dodatkowo na plus zwiekszenie planszy do 4x4, 5x5, lecz nie wymagane, aby otrzymac maksymalna ilosc punktow.
